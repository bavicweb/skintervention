<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/call-to-action/call-to-action.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/call-to-action/functions.php';